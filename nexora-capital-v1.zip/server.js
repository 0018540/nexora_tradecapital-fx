const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const db = new Database(path.join(__dirname, "data.db"));

db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user',
  available_balance REAL NOT NULL DEFAULT 0,
  invested_balance REAL NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  type TEXT NOT NULL,
  amount REAL NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  reference TEXT UNIQUE NOT NULL,
  note TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS investments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  amount REAL NOT NULL,
  plan TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS audit_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  admin_user_id INTEGER,
  action TEXT NOT NULL,
  target_type TEXT,
  target_id INTEGER,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

const adminEmail = process.env.ADMIN_EMAIL || "admin@nexoracapital.example";
const adminPassword = process.env.ADMIN_PASSWORD || "change-me-now";
const existingAdmin = db.prepare("SELECT id FROM users WHERE email=?").get(adminEmail);
if (!existingAdmin) {
  const hash = bcrypt.hashSync(adminPassword, 12);
  db.prepare("INSERT INTO users (name,email,password_hash,role) VALUES (?,?,?,'admin')")
    .run("Nexora Administrator", adminEmail, hash);
  console.log(`Admin created: ${adminEmail}`);
}

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(session({
  secret: process.env.SESSION_SECRET || "replace-this-in-production",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: false, maxAge: 1000*60*60*8 }
}));
app.use(express.static(path.join(__dirname, "public")));

function auth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: "Authentication required." });
  next();
}
function admin(req, res, next) {
  const u = req.session.userId && db.prepare("SELECT * FROM users WHERE id=?").get(req.session.userId);
  if (!u || u.role !== "admin") return res.status(403).json({ error: "Administrator access required." });
  req.user = u; next();
}
function ref(prefix) {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2,8).toUpperCase()}`;
}

app.post("/api/register", async (req,res)=>{
  const {name,email,password} = req.body;
  if (!name || !email || !password || password.length < 8)
    return res.status(400).json({error:"Name, valid email and password of at least 8 characters are required."});
  const normalized = email.trim().toLowerCase();
  if (db.prepare("SELECT id FROM users WHERE email=?").get(normalized))
    return res.status(409).json({error:"An account with that email already exists."});
  const hash = await bcrypt.hash(password,12);
  const result = db.prepare("INSERT INTO users (name,email,password_hash) VALUES (?,?,?)")
    .run(name.trim(), normalized, hash);
  req.session.userId = result.lastInsertRowid;
  res.json({ok:true});
});

app.post("/api/login", async (req,res)=>{
  const {email,password} = req.body;
  const u = db.prepare("SELECT * FROM users WHERE email=?").get((email||"").trim().toLowerCase());
  if (!u || !(await bcrypt.compare(password||"",u.password_hash)))
    return res.status(401).json({error:"Invalid email or password."});
  req.session.userId = u.id;
  res.json({ok:true, role:u.role});
});

app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));

app.get("/api/me",auth,(req,res)=>{
  const u = db.prepare("SELECT id,name,email,role,available_balance,invested_balance,created_at FROM users WHERE id=?").get(req.session.userId);
  res.json(u);
});

app.get("/api/dashboard",auth,(req,res)=>{
  const u = db.prepare("SELECT id,name,email,role,available_balance,invested_balance,created_at FROM users WHERE id=?").get(req.session.userId);
  const transactions = db.prepare("SELECT id,type,amount,status,reference,note,created_at FROM transactions WHERE user_id=? ORDER BY id DESC LIMIT 50").all(u.id);
  const investments = db.prepare("SELECT id,amount,plan,status,created_at FROM investments WHERE user_id=? ORDER BY id DESC LIMIT 50").all(u.id);
  res.json({user:u,transactions,investments});
});

app.post("/api/deposits",auth,(req,res)=>{
  const amount = Number(req.body.amount);
  if (!Number.isFinite(amount) || amount <= 0) return res.status(400).json({error:"Enter a valid positive amount."});
  const reference = ref("DEP");
  db.prepare("INSERT INTO transactions (user_id,type,amount,status,reference,note) VALUES (?,'deposit',?,'pending',?,?)")
    .run(req.session.userId,amount,reference,"Awaiting payment verification");
  res.json({ok:true,reference,status:"pending"});
});

app.post("/api/withdrawals",auth,(req,res)=>{
  const amount = Number(req.body.amount);
  if (!Number.isFinite(amount) || amount <= 0) return res.status(400).json({error:"Enter a valid positive amount."});
  const u = db.prepare("SELECT available_balance FROM users WHERE id=?").get(req.session.userId);
  if (amount > u.available_balance) return res.status(400).json({error:"Insufficient available balance."});
  const reference = ref("WDR");
  db.prepare("INSERT INTO transactions (user_id,type,amount,status,reference,note) VALUES (?,'withdrawal',?,'pending',?,?)")
    .run(req.session.userId,amount,reference,"Withdrawal request awaiting review");
  res.json({ok:true,reference,status:"pending"});
});

app.post("/api/investments",auth,(req,res)=>{
  const amount = Number(req.body.amount);
  const plan = String(req.body.plan||"").trim();
  if (!Number.isFinite(amount) || amount <= 0 || !plan) return res.status(400).json({error:"Investment amount and plan are required."});
  const u = db.prepare("SELECT available_balance FROM users WHERE id=?").get(req.session.userId);
  if (amount > u.available_balance) return res.status(400).json({error:"Insufficient available balance."});
  const tx = db.transaction(()=>{
    db.prepare("UPDATE users SET available_balance=available_balance-?, invested_balance=invested_balance+? WHERE id=?").run(amount,amount,req.session.userId);
    const r = db.prepare("INSERT INTO investments (user_id,amount,plan) VALUES (?,?,?)").run(req.session.userId,amount,plan);
    db.prepare("INSERT INTO transactions (user_id,type,amount,status,reference,note) VALUES (?,'investment',?,'completed',?,?)")
      .run(req.session.userId,amount,ref("INV"),"Funds moved into investment position");
    return r.lastInsertRowid;
  });
  res.json({ok:true,id:tx()});
});

app.get("/api/admin/overview",admin,(req,res)=>{
  const users = db.prepare("SELECT id,name,email,role,available_balance,invested_balance,created_at FROM users ORDER BY id DESC").all();
  const pending = db.prepare(`
    SELECT t.*, u.name, u.email FROM transactions t
    JOIN users u ON u.id=t.user_id
    WHERE t.status='pending' ORDER BY t.id ASC
  `).all();
  res.json({users,pending});
});

app.post("/api/admin/transactions/:id/approve",admin,(req,res)=>{
  const t = db.prepare("SELECT * FROM transactions WHERE id=?").get(req.params.id);
  if (!t || t.status !== "pending") return res.status(400).json({error:"Transaction is not pending."});
  const tx = db.transaction(()=>{
    if (t.type === "deposit") {
      db.prepare("UPDATE users SET available_balance=available_balance+? WHERE id=?").run(t.amount,t.user_id);
    } else if (t.type === "withdrawal") {
      const u = db.prepare("SELECT available_balance FROM users WHERE id=?").get(t.user_id);
      if (u.available_balance < t.amount) throw new Error("User no longer has sufficient balance.");
      db.prepare("UPDATE users SET available_balance=available_balance-? WHERE id=?").run(t.amount,t.user_id);
    }
    db.prepare("UPDATE transactions SET status='completed', note=? WHERE id=?").run("Verified and approved by administrator",t.id);
    db.prepare("INSERT INTO audit_logs (admin_user_id,action,target_type,target_id) VALUES (?,?,?,?)")
      .run(req.user.id,"approve_transaction","transaction",t.id);
  });
  try { tx(); res.json({ok:true}); } catch(e) { res.status(400).json({error:e.message}); }
});

app.post("/api/admin/transactions/:id/reject",admin,(req,res)=>{
  const t = db.prepare("SELECT * FROM transactions WHERE id=?").get(req.params.id);
  if (!t || t.status !== "pending") return res.status(400).json({error:"Transaction is not pending."});
  db.prepare("UPDATE transactions SET status='rejected', note=? WHERE id=?").run("Rejected by administrator",t.id);
  db.prepare("INSERT INTO audit_logs (admin_user_id,action,target_type,target_id) VALUES (?,?,?,?)")
    .run(req.user.id,"reject_transaction","transaction",t.id);
  res.json({ok:true});
});

app.get("/api/admin/audit",admin,(req,res)=>{
  res.json(db.prepare("SELECT * FROM audit_logs ORDER BY id DESC LIMIT 100").all());
});

app.listen(PORT,()=>console.log(`Nexora Capital running at http://localhost:${PORT}`));
