# Nexora Capital

A mobile-friendly investment-platform starter with server-side account balances.

## Included
- Public landing page
- Registration and login
- Server-side SQLite database
- Password hashing with bcrypt
- Session authentication
- Investor dashboard
- Deposit requests
- Withdrawal requests
- Investment records
- Transaction history
- Admin dashboard
- Admin approval/rejection workflow
- Audit log
- $0 starting balance for new accounts
- No hard-coded profits or fabricated transactions

## Run locally

Requires Node.js 20+.

```bash
npm install
npm start
```

Open http://localhost:3000

### Demo admin
On first startup, an admin account is created from these environment variables:
- ADMIN_EMAIL (default: admin@nexoracapital.example)
- ADMIN_PASSWORD (default: change-me-now)

Change these values before any real deployment.

## Important production work
This starter intentionally does NOT process real money. Before accepting deposits:
- complete applicable business/financial registration and licensing
- add KYC/AML controls appropriate to your jurisdiction
- connect a regulated payment provider
- implement provider webhook signature verification
- use HTTPS and secure production secrets
- add 2FA, rate limiting, CSRF protections where applicable, monitoring, backups and incident response
- have the investment terms, fees, risk disclosures and customer agreements reviewed by qualified professionals

Never credit a deposit or investment merely because a user says they paid. Credit only after verified provider/bank settlement.
