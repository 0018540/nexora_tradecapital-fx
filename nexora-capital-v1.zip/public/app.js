const $=s=>document.querySelector(s);
function showAuth(mode){
  $("#auth").classList.remove("hidden");
  $("#authContent").innerHTML=mode==="login"?`
  <p class="eyebrow">WELCOME BACK</p><h2>Sign in</h2>
  <form onsubmit="login(event)"><input id="email" type="email" placeholder="Email" required><input id="password" type="password" placeholder="Password" required><button class="primary wide">Sign in</button><p id="msg"></p></form>
  <p class="switch">New here? <button onclick="showAuth('register')">Create an account</button></p>`:`
  <p class="eyebrow">GET STARTED</p><h2>Create account</h2>
  <form onsubmit="register(event)"><input id="name" placeholder="Full name" required><input id="email" type="email" placeholder="Email" required><input id="password" type="password" placeholder="Password (8+ characters)" minlength="8" required><button class="primary wide">Create account</button><p id="msg"></p></form>
  <p class="switch">Already registered? <button onclick="showAuth('login')">Sign in</button></p>`;
}
function hideAuth(){ $("#auth").classList.add("hidden"); }
async function register(e){e.preventDefault(); const r=await fetch("/api/register",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name:$("#name").value,email:$("#email").value,password:$("#password").value})}); const d=await r.json(); if(!r.ok)return $("#msg").textContent=d.error; location.href="/dashboard.html";}
async function login(e){e.preventDefault(); const r=await fetch("/api/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email:$("#email").value,password:$("#password").value})}); const d=await r.json(); if(!r.ok)return $("#msg").textContent=d.error; location.href=d.role==="admin"?"/admin.html":"/dashboard.html";}
